.. _examples :

Example Notebooks
=================

Here are some example Jupyter Notebooks!

.. toctree::
   :maxdepth: 1
   :caption: Simple Examples
   
   notebooks/planck_demo.ipynb
   notebooks/maxwell_boltzmann_demo.ipynb
   notebooks/boltzmann_factor_demo.ipynb