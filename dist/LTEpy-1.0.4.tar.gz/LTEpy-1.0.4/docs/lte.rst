.. _lte:

LTE
===============================

Local Thermodynamic Equilibrium

.. module:: LTEpy

.. automodule:: LTEpy.lte
   :members: