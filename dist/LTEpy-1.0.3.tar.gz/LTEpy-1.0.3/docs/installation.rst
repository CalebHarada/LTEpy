.. _installation:

Installation
=============

``LTEpy`` is pip installable! 

.. code-block:: console

    $ pip install LTEpy


To test your installation, ``cd`` into the root directory of ``LTEpy`` and run

.. code-block:: console

    $ py.test


